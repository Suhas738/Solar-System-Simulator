import React,{useState} from 'react';
import MyCalender from '../components/Calender'
import Navbar from '../components/Calender/Navbarcalendar';
import Footer from '../components/footer/index'




const Calender = () => {

    
   // 

  
    return (
        <>
        <Navbar/>
         <MyCalender/>
         <Footer/>
        </>
    );
}

export default Calender;


