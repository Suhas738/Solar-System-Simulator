import React ,{useState ,useEffect} from 'react'
import SignIn from '../components/Signin'
import fire from '../components/login system/firebase'

const SigninPage = (props) => {

   
    return (
        <>
           <SignIn />
        </>
    )
}

export default SigninPage;
