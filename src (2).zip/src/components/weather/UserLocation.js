import React from 'react'
import Navbar from './NavbarWeather'
import {WeatherH1,WeatherContainer,WeatherCard,WeatherCard1,WeatherWrapper,WeatherWrapper1} from './WeatherElements'
export default function UserLocation(props) {

    const { temperature, description, location, region, country, wind_speed, pressure, precip, humidity, img ,cloudcover,wind_cover,wind_degree,  wind_dir} = props.weather;
    

    return (
        <div className="user-weather">

            <WeatherWrapper1>
            <WeatherCard1>
            <div className="row">
            
                <div className="col-md-3 weather-temp">
                
                    <h1>{temperature}<sup>o</sup>C , {description}</h1>
                    <p>{location},{region} , {country}</p>
                    <img className="mainImg" src={img} alt="weather-img" />
                </div>

                
                
               
            </div>
            
            </WeatherCard1>
            <div className="row">
            <WeatherCard1>
            <div className="col-md-3 weather-info">
                    <p><b>Preassure</b>(millibar)</p>
                    <h2>{pressure}</h2>
                </div>
           </WeatherCard1>
           <WeatherCard1>
           <div className="col-md-3 weather-info">
           <p><b>Precipitation</b>(mm)</p>
                    <h2>{precip}</h2>
                </div>
           </WeatherCard1>
           
           </div>
            </WeatherWrapper1>
            <WeatherWrapper>
            <WeatherCard>
                <div className="col-md-3 weather-info">
                    <p><b>Wind</b>(km/hr)</p>
                    <h2>{wind_speed}</h2>
                </div>
                </WeatherCard>
                <WeatherCard>
                <div className="col-md-3 weather-info">
                   
                     <p><b>Humidity</b>(%)</p>
                    <h2>{humidity}</h2>
                </div>
                </WeatherCard>
                <WeatherCard>
                <div className="col-md-3 weather-info">
                    <p><b>Wind degree</b></p>
                    <h2>{wind_degree}</h2>
                </div>
                </WeatherCard>
                <WeatherCard>
                <div className="col-md-3 weather-info">
                <p><b>Wind dir</b></p>
                    <h2>{wind_dir}</h2>
                </div>
                </WeatherCard>
            </WeatherWrapper>
        </div>
    )
}
