

export const homeObjOne = {

 id:'signup',
 lightBg:true,
 lightText:true,
 lightTextDesc:true,
 topLine:'Dont have an account ?  ',
 headline:'Sign-up',
 description:'Free of Cost',
 buttonLabel:'get started',
 imgStart:'true',
 img:require("../../images/undraw_Design_feedback_re_8gtk (1).png"),
 alt:'why the fuck is this not working',
 dark:true,
 primary:true,
 darkText:false,
 link:"/signup"
};

export const homeObjtwo = {

    id:'apod',
    lightBg:true,
    lightText:true,
    lightTextDesc:true,
    topLine:'Sign-up',
    headline:'',
    description:'Free of Cost',
    buttonLabel:'get started',
    imgStart:'true',
    img:require('../../images/svg-1.svg'),
    alt:'Car',
    dark:true,
    primary:true,
    darkText:false,
    link:"/apod"
   
   };

   export const homeObjthree = {

    id:'about',
    lightBg:false,
    lightText:true,
    lightTextDesc:true,
    topLine:'',
    headline:'About',
    description:'This is an educational website used for astronomicalLorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown  took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum..',
    buttonLabel:'About Us',
    imgStart:'true',
    img: 'https://th.bing.com/th/id/OIP.HDQTfZejCZE1VXFzBlUZoQHaEc?w=300&h=180&c=7&o=5&dpr=1.12&pid=1.7',
    alt:'Car',
    dark:true,
    primary:true,
    darkText:false,
    link:"/apod"
   
   };