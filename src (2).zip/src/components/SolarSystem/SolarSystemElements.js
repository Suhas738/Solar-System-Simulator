import styled from 'styled-components'
import {Link as Linkr} from 'react-router-dom'

export const SolarLink = styled.a `

text-decoration:none;


`

export const SolarContainer = styled.div `

padding:0;
margin:0px;
max-height:auto;
overflow:hidden;

`
export const Heading = styled(Linkr)`

background:black;
color:white
padding-left:50px;
`

