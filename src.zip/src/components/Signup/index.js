import React , {useRef,useState,Component} from 'react'
import { useAuth } from '../login system/contexts/AuthContext';
import {Alert } from "react-bootstrap"
import fire from '../login system/firebase'
import {

    Container,FormWrap,Icon,FormContent,Form,FormH1,FormLabel,FormInput,FormButton,Text
} from './SignupElements.js'
import Navbar from './Navbarcalendar'


class Signup extends Component{


    signUp() {
       
        const email = document.querySelector('#email').value;
        const password = document.querySelector('#password').value;
        fire.auth().createUserWithEmailAndPassword(email, password)
          .then((u) => {
            console.log('Successfully Signed Up');
            
          })
          .catch((err) => {
            console.log('Error: ' + err.toString());
          })
      }
    
    render(){

    
    return (

        <>
         <Container>
         <Navbar/>
            <FormWrap>
                <FormContent>
                    <Form >
                        <FormH1>Sign up your Account</FormH1>
                        <FormLabel htmlFor='for'>Email</FormLabel>
                        <FormInput type='email' required  id="email"/>
                        <FormLabel htmlFor='for'>Password</FormLabel>
                        <FormInput type='password' required  id="password"/>
                        <FormButton type='submit' onClick={this.signUp}> Sign up</FormButton>
                        <Text to="/signin">Login</Text>
                    </Form>
                </FormContent>
            </FormWrap>
        </Container>
        </>

    )}
}

export default Signup
