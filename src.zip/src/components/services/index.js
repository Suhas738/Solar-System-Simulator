import React from 'react'

import Icon1 from '../../images/OIP.jfif'
import Icon2 from '../../images/undraw_secure_files_re_6vdh.svg'
import Icon3 from '../../images/svg-1.svg'
import Video from '../../video/video.mp4'

import {ServicesContainer,ServicesH1,ServicesWrapper,ServicesCard,ServicesIcon,ServicesH2,ServicesP,ServicesCardLink} from './ServiceElements'
import {HeroBg,VideoBg,} from '../HeroSection/HeroElements'


const Services = () => {
    return (
        <ServicesContainer id="services"> 
          <HeroBg>
                <VideoBg autoPlay loop muted src={Video} type='video/mp4'/>
            </HeroBg>
            <ServicesH1>EVENTS</ServicesH1>
            <ServicesWrapper>
                <ServicesCard>
                <ServicesCardLink to="/Star">
                    <ServicesIcon src={Icon1} />
                    <ServicesH2>Constellations and Nebulas</ServicesH2>
                    <ServicesP>Information about stars in the constellations and nebulas</ServicesP>
                    </ServicesCardLink>
                </ServicesCard>
                <ServicesCard>
                <ServicesCardLink to="/Planet">
                    <ServicesIcon src={Icon2} />
                    <ServicesH2>Galaxies</ServicesH2>
                    <ServicesP>We help reduce your fess and increase your overall revenue</ServicesP>
                 </ServicesCardLink>
                </ServicesCard>

                <ServicesCard >
                    
                    <ServicesCardLink to="/Calender">
                    <ServicesIcon src={Icon3} />
                    <ServicesH2>Events Calendar</ServicesH2>
                    <ServicesP>We help reduce your fess and increase your overall revenue</ServicesP>
                    </ServicesCardLink>
                    
                </ServicesCard>
            </ServicesWrapper>
        </ServicesContainer>
    )
}

export default Services
