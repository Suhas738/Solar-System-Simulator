import styled from 'styled-components'

export const SolarLink = styled.a `

text-decoration:none;


`

export const SolarContainer = styled.div `

padding:0;
margin:0px;
max-height:auto;
overflow:hidden;

`