import firebase from 'firebase'
//import  'firebase/auth'


var firebaseConfig = {
  apiKey: "AIzaSyAlJE6036JS2_G8MF6NcVAeBV7ZzbkyK4w",
  authDomain: "solar-system-6987f.firebaseapp.com",
  databaseURL: "https://solar-system-6987f-default-rtdb.firebaseio.com",
  projectId: "solar-system-6987f",
  storageBucket: "solar-system-6987f.appspot.com",
  messagingSenderId: "490377505316",
  appId: "1:490377505316:web:3307a7152172937dcb86b1"
};

const fire = firebase.initializeApp(firebaseConfig);

 export default fire; 