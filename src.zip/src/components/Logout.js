import React from 'react'


class Logout extends React.Component {

    logout() {
      fire.auth().signOut();
    }
  
    render() {
      return (
        <>
          <button onClick = {this.logout}>Logout</button>
        </>
      )
    }
  }
  
  export default Logout;

export default Logout
