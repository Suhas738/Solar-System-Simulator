import React,{useState,Component} from 'react'
import {
    Container,FormWrap,Icon,FormContent,Form,FormH1,FormLabel,FormInput,FormButton,Text,Text1
} from './SigninElements.js'
import fire from '../login system/firebase'
import Navbar from './Navbarcalendar'

class  SignIn extends Component {

    login() {
        const email = document.querySelector('#email').value;
        const password = document.querySelector('#password').value;
        fire.auth().signInWithEmailAndPassword(email, password)
          .then((u) => {
            console.log('Successfully Logged In');
          })
          .catch((err) => {
            console.log('Error: ' + err.toString());
          })
      }

   render(){
    return (
        <>
        <Container>

            <Navbar/>
            <FormWrap>
                
                <FormContent>
                    <Form >

                        <FormH1>Sign in your Account</FormH1>
                        <FormLabel htmlFor='for'>Email</FormLabel>
                        <FormInput type='email' required id="email"/>
                        <FormLabel htmlFor='for'>Password</FormLabel>
                        <FormInput type='password' required id="password" />
                        <FormButton type='submit' onClick={this.login}> Sign in</FormButton>
                        <Text1>Dont have an Account? </Text1>
                        <Text to="/signup">sign up</Text>
                                    
                    </Form>
                </FormContent>
            </FormWrap>
        </Container>
            
        </>
    )
   }
}

export default SignIn
