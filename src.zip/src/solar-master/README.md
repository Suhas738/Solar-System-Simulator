# Solar
A interactive solar system using THREE.js

Models used are in GLTF format (Highly Compressed)

For demo visit --> [DEMO](http://amitkan1995.github.io/solar)
