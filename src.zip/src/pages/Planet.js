import React from 'react'
import Planet from '../components/planets/index'
import Navbar from '../components/planets/Navbarcalendar'
import Footer from '../components/footer/index'

const Planet1 = () => {
    return (
        <div>
            <Navbar/>
            <Planet/>
            <Footer/>
        </div>
    )
}

export default Planet1
