
import React from 'react'
import Star from '../components/star/index'
import Navbar from '../components/star/Navbarcalendar'
import Footer from '../components/footer/index'

const Star1 = () => {
    return (
        <div>

            <Navbar/>
            <Star/>
            <Footer/>
            
        </div>
    )
}

export default Star1
